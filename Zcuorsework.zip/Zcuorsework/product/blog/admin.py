from django.contrib import admin
from .models import Goog, Reviews

admin.site.register(Goog)
admin.site.register(Reviews)
